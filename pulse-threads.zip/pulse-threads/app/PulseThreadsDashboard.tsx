[Insert the full code from the canvas here]
